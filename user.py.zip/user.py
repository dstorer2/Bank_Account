class User():
    bank_name = "First National Dojo"
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address
        self.account_balance = 0
    def make_deposit(self, amount):
        self.account_balance += amount
    def make_withdrawal(self, amount):
        self.account_balance -= amount
    def display_user_balance(self):
        print(f"User: {self.name}, Blanace: {self.account_balance}")
    def transfer_money(self, other_user, amount):
        print("Before the transfer, ", self.name, "'s balance is ", self.account_balance, "and ", other_user.name, "'s balance is ", other_user.account_balance)
        self.account_balance -= amount
        other_user.account_balance += amount
        print("After the transfer, the respective accounts stand at ", self.account_balance, " and ", other_user.account_balance)




guido = User("Guido van Rossum", "guido@python.com")
monty = User("Monty Python", "monty@python.com")
snape = User("Professor Snape", "snape@hogwarts.com")

guido.make_deposit(100)
guido.make_deposit(10000000)
guido.make_withdrawal(59468)
guido.display_user_balance()

monty.make_deposit(12)
monty.make_deposit(453156)
monty.make_withdrawal(1)
monty.make_withdrawal(7)
monty.display_user_balance()

snape.make_deposit(15000)
snape.make_withdrawal(1536)
snape.make_withdrawal(135)
snape.make_withdrawal(14)
snape.display_user_balance()

guido.transfer_money(snape, 1000000)



