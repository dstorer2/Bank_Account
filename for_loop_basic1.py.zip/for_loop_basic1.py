# for x in range(0, 151):
#     print(x)

# for x in range(5, 1000, 5):
#     print(x)

# import math

# for x in range(1, 101):
#     if math.remainder(x, 10) == 0:
#         print("Coding Dojo")
#     elif math.remainder(x, 5) == 0:
#         print("Coding")
#     else:
#         print(x)

# sum = 1

# for x in range(1, 500000, 2):
#     sum += x

# print(sum)

# for x in range(2018, 0, -4):
#     print(x)

# import math


# lowNum = 4
# highNum = 50
# mult = 4

# for x in range(lowNum, highNum, 1):
#     if math.remainder(x, mult) == 0:
#         print(x)